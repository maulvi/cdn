<?
class Filed extends AppModel {
	/////(Telegram:@qqqwqws) by ink.
  //var $belongsTo = 'Post';
   var $name = 'Filed';
   //  var $hasOne = 'Post';
   var $hasMany = 'Multi';   	
}

